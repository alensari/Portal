from django.contrib import admin
from . import models
# Register your models here.
admin.site.register(models.Diskusija)
admin.site.register(models.Stavka)
